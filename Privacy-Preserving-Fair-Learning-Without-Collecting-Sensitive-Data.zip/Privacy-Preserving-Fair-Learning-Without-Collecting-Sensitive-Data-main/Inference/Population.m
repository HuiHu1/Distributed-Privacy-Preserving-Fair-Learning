function Y = Population(p,n)
%p: population size
%n: dimension
Y = randi([0 1],p,n);
end

